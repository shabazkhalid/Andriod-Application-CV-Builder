package com.example.shabaz.cvbuilderoffline;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by shabaz on 11/28/2017.
 */

public class database extends SQLiteOpenHelper {


    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "CVBUILDER";
    // Contacts table name
    private static final String TABLE_BUILDER = "information";
    // Contacts Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_FNAME = "firstname";
    private static final String KEY_LNAME = "lastname";
    private static final String KEY_MOBILE = "mobile";
    private static final String KEY_DOBIRTH = "dateofbirth";
    private static final String KEY_E_MAIL = "email";
    private static final String KEY_INSTI1 = "institute1";
    private static final String KEY_INSTI2 = "institute2";
    private static final String KEY_INSTI3 = "institute3";
    private static final String KEY_MARK1 = "marks1";
    private static final String KEY_MARK2 = "marks2";
    private static final String KEY_MARK3 = "marks3";
    private static final String KEY_DATE1 = "date1";
    private static final String KEY_DATE2 = "date2";
    private static final String KEY_ADATE1 = "awarddate1";
    private static final String KEY_ADATE2 = "awarddate2";
    private static final String KEY_EXPERIENCE1 = "experience1";
    private static final String KEY_EXPERIENCE2 = "experience2";
    private static final String KEY_AEXPERIENCE1 = "awardexperience1";
    private static final String KEY_AEXPERIENCE2 = "awardexperience2";

    public database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_BUILDER_TABLE = "CREATE TABLE " + TABLE_BUILDER + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_FNAME + " TEXT,"
                + KEY_LNAME + " TEXT," + KEY_MOBILE + " TEXT,"+ KEY_DOBIRTH + " TEXT,"+ KEY_E_MAIL
                + " TEXT,"+ KEY_INSTI1 + " TEXT,"+ KEY_INSTI2 + " TEXT,"+ KEY_INSTI3 + " TEXT,"+ KEY_MARK1
                + " TEXT,"+ KEY_MARK2 + " TEXT,"+ KEY_MARK3 + " TEXT,"+ KEY_DATE1 + " TEXT,"+ KEY_DATE2
                + " TEXT,"+ KEY_ADATE1 + " TEXT,"+ KEY_ADATE2 + " TEXT,"+ KEY_EXPERIENCE1 + " TEXT,"+ KEY_EXPERIENCE2
                + " TEXT,"+ KEY_AEXPERIENCE1 + " TEXT,"+ KEY_AEXPERIENCE2 + " TEXT "+ ")";

        db.execSQL(CREATE_BUILDER_TABLE);
    }
    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
// Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BUILDER);
// Create tables again
        onCreate(db);
    }
    // Adding new contact
    void addContact(builder b) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_FNAME, b.getfname()); // Contact Name
        values.put(KEY_LNAME, b.getlname());
        values.put(KEY_MOBILE, b.getmobile());
        values.put(KEY_DOBIRTH, b.getdobirth());
        values.put(KEY_E_MAIL, b.getemail());
        values.put(KEY_INSTI1, b.getinsti1());
        values.put(KEY_INSTI2, b.getinsti2());
        values.put(KEY_INSTI3, b.getinsti3());
        values.put(KEY_MARK1, b.getmark1());
        values.put(KEY_MARK2, b.getmark2());
        values.put(KEY_MARK3, b.getmark3());
        values.put(KEY_DATE1, b.getdate1());
        values.put(KEY_DATE2, b.getdate2());
        values.put(KEY_ADATE1, b.getadate1());
        values.put(KEY_ADATE2, b.getadate2());
        values.put(KEY_EXPERIENCE1, b.getexperience1());
        values.put(KEY_EXPERIENCE2, b.getexperience2());
        values.put(KEY_AEXPERIENCE1, b.getaexperience1());
        values.put(KEY_AEXPERIENCE2, b.getaexperience2());

        // Contact Phone
// Inserting Row
        db.insert(TABLE_BUILDER, null, values);
        db.close(); // Closing database connection
    }
    /* // Getting single contact
     Contact getContact(int id) {
         SQLiteDatabase db = this.getReadableDatabase();
         Cursor cursor = db.query(TABLE_CONTACTS, new String[] { KEY_ID,
                         KEY_NAME, KEY_PH_NO }, KEY_ID + "=?",
                 new String[] { String.valueOf(id) }, null, null, null, null);
         if (cursor != null)
             cursor.moveToFirst();
         Contact contact = new Contact(Integer.parseInt(cursor.getString(0)),
                 cursor.getString(1), cursor.getString(2));
 // return contact
         return contact;
     }

     boolean checkIfExist(String name) {
         SQLiteDatabase db = this.getReadableDatabase();
         Cursor cursor = db.query(TABLE_CONTACTS, new String[] { KEY_ID,
                         KEY_NAME, KEY_PH_NO }, KEY_PH_NO + "=?",
                 new String[] { name }, null, null, null, null);
         if (cursor.getCount() > 0)
             return true;
         else
             return false;
     }*/
    // Getting All Contacts
    public List<builder> getAllContacts() {
        List<builder> contactList = new ArrayList<builder>();
// Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_BUILDER;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
// looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                builder b = new builder();
                b.setID(Integer.parseInt(cursor.getString(0)));
                b.setfname(cursor.getString(1));
                b.setlname(cursor.getString(2));
                 b.setmobile(cursor.getString(3));
                b.setdobirth(cursor.getString(4));
                b.setemail(cursor.getString(5));
                b.setinsti1(cursor.getString(6));
                b.setinsti2(cursor.getString(7));
                b.setinsti3(cursor.getString(8));
                b.setmark1(cursor.getString(9));
                b.setmark2(cursor.getString(10));
                b.setmark3(cursor.getString(11));
                b.setdate1(cursor.getString(12));
                b.setdate2(cursor.getString(13));
                b.setadate1(cursor.getString(14));
                b.setadate2(cursor.getString(15));
                b.setexperience1(cursor.getString(16));
                b.setexperience2(cursor.getString(17));
                b.setaexperience1(cursor.getString(18));
                b.setaexperience2(cursor.getString(19));




// Adding contact to list
                contactList.add(b);
            } while (cursor.moveToNext());
        }
// return contact list
        return contactList;
    }
    // Updating single contact and update with phone
 /*   public int updateContact_Phone(Contact contact,String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, contact.getName());
        values.put(KEY_PH_NO, contact.getPhoneNumber());
// updating row
        return db.update(TABLE_CONTACTS, values, KEY_PH_NO + " = ?",
                new String[] { phone });
    }
    // Deleting single contact
    public void deleteContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CONTACTS, KEY_PH_NO + " = ?",
                new String[] { contact.getPhoneNumber() });
        db.close();
    }
    */
    //Getting contacts Count
    public int getContactsCount() {
        String countQuery = "SELECT * FROM " + TABLE_BUILDER;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();
// return count
        return cursor.getCount();
    }




}

