package com.example.shabaz.cvbuilderoffline;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

public class profile extends Activity {
    String firstname;
    String lastname;
    String mobile;
    String dateofbirth;
    String email;
    String institute1;
    String institute2;
    String institute3;
    String marks1;
    String marks2;
    String marks3;
    String date1;
    String date2;
    String awarddate1;
    String awarddate2;
    String experience1;
    String experience2;
    String awardexperience1;
    String awardexperience2;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        TextView fName = (TextView) findViewById(R.id.fname);
        TextView lName = (TextView) findViewById(R.id.lname);
        TextView Mobile = (TextView) findViewById(R.id.mob);
        TextView Dobirth = (TextView) findViewById(R.id.dob);
        TextView Email = (TextView) findViewById(R.id.email);
        TextView Insti1 = (TextView) findViewById(R.id.inst1);
        TextView Insti2 = (TextView) findViewById(R.id.inst2);
        TextView Insti3 = (TextView) findViewById(R.id.inst3);
        TextView Mark1 = (TextView) findViewById(R.id.mrk1);
        TextView Mark2 = (TextView) findViewById(R.id.mrk2);
        TextView Mark3 = (TextView) findViewById(R.id.mrk3);
        TextView Date1 = (TextView) findViewById(R.id.dte1);
        TextView Date2 = (TextView) findViewById(R.id.dte2);
        TextView ADate1 = (TextView) findViewById(R.id.adte1);
        TextView ADate2 = (TextView) findViewById(R.id.adte2);
        TextView EXP1 = (TextView) findViewById(R.id.exp1);
        TextView EXP2 = (TextView) findViewById(R.id.exp2);
        TextView AEXP1 = (TextView) findViewById(R.id.aexp1);
        TextView AEXP2 = (TextView) findViewById(R.id.aexp2);

       // TextView txtProduct = (TextView) findViewById(R.id.chk);
        Intent i = getIntent();
        // getting attached intent data
        String product = i.getStringExtra("product");
// displaying selected product name

        String string = product;
        String[] parts = string.split("-");
        String part1 = parts[0];

      //  txtProduct.setText(part1);

String k= "shabaz";

        database db = new database(this);
// Reading all contacts
        Log.d("Reading: ", "Reading all contacts..");
        List<builder> contacts = db.getAllContacts();
        String log=null;
        String [] contact_array = new String[contacts.size()];
        int j=0;
        for (builder cn : contacts) {
            if(part1.equals(cn.getfname()))
            {
                firstname=cn.getfname();
                lastname=cn.getlname();

                mobile=cn.getmobile();
                dateofbirth=cn.getdobirth();
                 email=cn.getemail();
                institute1=cn.getinsti1();
                 institute2=cn.getinsti2();
                 institute3=cn.getinsti3();
                marks1=cn.getmark1();
                marks2=cn.getmark2();
                marks3=cn.getmark3();
                 date1=cn.getadate1();
                date2=cn.getdate2();
                 awarddate1=cn.getadate1();
                 awarddate2=cn.getadate2();
                experience1=cn.getexperience1();
                 experience2=cn.getexperience2();
                awardexperience1=cn.getaexperience1();
                 awardexperience2=cn.getaexperience2();

                //lName.setText(cn.getlname());
                //txtProduct.setText("shabaz123");
            }
            //log = log + "Id: " + cn.getID() + " ,Name: " + cn.getfname() + ",Phone: " + cn.getlname();
// Writing Contacts to log
            // Log.d("Name: ", log);
            j++;
        }
        fName.setText(firstname);
        lName.setText(lastname);
    Mobile.setText(mobile);
        Dobirth.setText(dateofbirth);
        Email.setText(email);
        Insti1.setText(institute1);
        Insti2.setText(institute2);
        Insti3.setText(institute3);
        Mark1.setText(marks1);
        Mark2.setText(marks2);
        Mark3.setText(marks3);
        Date1.setText(date1);
        Date2.setText(date2);
        ADate1.setText(awarddate1);
        ADate2.setText(awarddate2);
        EXP1.setText(experience1);
        EXP2.setText(experience2);
        AEXP1.setText(awardexperience1);
        AEXP2.setText(awardexperience2);





    }
    }

