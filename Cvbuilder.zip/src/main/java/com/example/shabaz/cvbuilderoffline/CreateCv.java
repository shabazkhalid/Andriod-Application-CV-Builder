package com.example.shabaz.cvbuilderoffline;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.File;

import static android.R.attr.data;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class CreateCv extends AppCompatActivity implements OnClickListener {

    // Image loading result to pass to startActivityForResult method.
    private static int LOAD_IMAGE_RESULTS = 1;

    // GUI components
    private Button button;  // The button
    //  private ImageView image;// ImageView

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_cv);

        // Find references to the GUI objects
        button = (Button)findViewById(R.id.button);
        //
        // image = (ImageView)findViewById(R.id.image);

        // Set button's onClick listener object.
        button.setOnClickListener(this);

        Button btnNextScreen = (Button) findViewById(R.id.bttn);
//Listening to button event
        btnNextScreen.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                EditText fName = (EditText) findViewById(R.id.fname);
                EditText lName = (EditText) findViewById(R.id.lname);
                EditText Mobile = (EditText) findViewById(R.id.mob);
                EditText Dobirth = (EditText) findViewById(R.id.dob);
                EditText Email = (EditText) findViewById(R.id.email);
                EditText Insti1 = (EditText) findViewById(R.id.inst1);
                EditText Insti2 = (EditText) findViewById(R.id.inst2);
                EditText Insti3 = (EditText) findViewById(R.id.inst3);
                EditText Mark1 = (EditText) findViewById(R.id.mrk1);
                EditText Mark2 = (EditText) findViewById(R.id.mrk2);
                EditText Mark3 = (EditText) findViewById(R.id.mrk3);
                EditText Date1 = (EditText) findViewById(R.id.dte1);
                EditText Date2 = (EditText) findViewById(R.id.dte2);
                EditText ADate1 = (EditText) findViewById(R.id.adte1);
                EditText ADate2 = (EditText) findViewById(R.id.adte2);
                EditText EXP1 = (EditText) findViewById(R.id.exp1);
                EditText EXP2 = (EditText) findViewById(R.id.exp2);
                EditText AEXP1 = (EditText) findViewById(R.id.aexp1);
                EditText AEXP2 = (EditText) findViewById(R.id.aexp2);

// Add in database
                database db = new database(CreateCv.this);
                Log.d("Insert: ", "Inserting ..");
                db.addContact(new builder(fName.getText().toString(), lName.getText().toString(),
                        Mobile.getText().toString(), Dobirth.getText().toString(), Email.getText().toString(),
                        Insti1.getText().toString(), Insti2.getText().toString(), Insti3.getText().toString(),
                        Mark1.getText().toString(), Mark2.getText().toString(), Mark3.getText().toString(),
                        Date1.getText().toString(), Date2.getText().toString(), ADate1.getText().toString(),
                        ADate2.getText().toString(), EXP1.getText().toString(), EXP2.getText().toString(),
                        AEXP1.getText().toString(), AEXP2.getText().toString()));
                Toast.makeText(getApplicationContext(), "Contact Added Successfully" + fName.getText(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Here we need to check if the activity that was triggers was the Image Gallery.
        // If it is the requestCode will match the LOAD_IMAGE_RESULTS value.
        // If the resultCode is RESULT_OK and there is some data we know that an image was picked.
        if (requestCode == LOAD_IMAGE_RESULTS && resultCode == RESULT_OK && data != null) {
            // Let's read picked image data - its URI
            Uri pickedImage = data.getData();
            // Let's read picked image path using content resolver
            String[] filePath = { MediaStore.Images.Media.DATA };
            Cursor cursor = getContentResolver().query(pickedImage, filePath, null, null, null);
            cursor.moveToFirst();
            String imagePath = cursor.getString(cursor.getColumnIndex(filePath[0]));

            // Now we need to set the GUI ImageView data with data read from the picked file.
            // image.setImageBitmap(BitmapFactory.decodeFile(imagePath));

            // At the end remember to close the cursor or you will end with the RuntimeException!
            cursor.close();
        }
    }

    @Override
    public void onClick(View v) {
        // Create the Intent for Image Gallery.
        Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        // Start new activity with the LOAD_IMAGE_RESULTS to handle back the results when image is picked from the Image Gallery.
        startActivityForResult(i, LOAD_IMAGE_RESULTS);




    }


}

