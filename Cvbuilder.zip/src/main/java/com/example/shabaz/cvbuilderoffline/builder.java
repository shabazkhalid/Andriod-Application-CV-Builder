package com.example.shabaz.cvbuilderoffline;

/**
 * Created by shabaz on 11/29/2017.
 */

public class builder {


    //private variables
    int _id;
    String f_name;
    String l_name;
    String mobile;
    String dobirth;
    String E_mail;
    String insti1;
    String insti2;
    String insti3;
    String mark1;
    String mark2;
    String mark3;
    String date1;
    String date2;
    String adate1;
    String adate2;
    String experience1;
    String experience2;
    String aexperience1;
    String aexperience2;


    // Empty constructor
    public builder(){
    }
    // constructor
    public builder(     int _id,String f_name,String l_name ,String mobile,String dobirth,String E_mail,String insti1,String insti2,String insti3,String mark1,String mark2,String mark3,String date1,String date2,String adate1,String adate2,String experience1,String experience2,String aexperience1,String aexperience2) {

        this. _id=_id;
        this. f_name=f_name;
        this. l_name=l_name;
        this. mobile=mobile;
        this. dobirth=dobirth;
        this. E_mail=E_mail;
        this. insti1=insti1;
        this. insti2=insti2;
        this. insti3=insti3;
        this. mark1=mark1;
        this. mark2=mark2;
        this. mark3=mark3;
        this. date1=date1;
        this. date2=date2;
        this. adate1=adate1;
        this. adate2=adate2;
        this. experience1=experience1;
        this. experience2=experience2;
        this. aexperience1=aexperience1;
        this. aexperience2=aexperience2;
    }
    // constructor
    public builder(String f_name,String l_name ,String mobile,String dobirth,String E_mail,String insti1,String insti2,String insti3,String mark1,String mark2,String mark3,String date1,String date2,String adate1,String adate2,String experience1,String experience2,String aexperience1,String aexperience2) {
        this. f_name=f_name;
        this. l_name=l_name;
        this. mobile=mobile;
        this. dobirth=dobirth;
        this. E_mail=E_mail;
        this. insti1=insti1;
        this. insti2=insti2;
        this. insti3=insti3;
        this. mark1=mark1;
        this. mark2=mark2;
        this. mark3=mark3;
        this. date1=date1;
        this. date2=date2;
        this. adate1=adate1;
        this. adate2=adate2;
        this. experience1=experience1;
        this. experience2=experience2;
        this. aexperience1=aexperience1;
        this. aexperience2=aexperience2;
    }
    // getting ID
    public int getID(){
        return this._id;
    }
    // setting id
    public void setID(int id){
        this._id = id;
    }
    // getting name
    public String getfname(){
        return this.f_name;
    }
    // setting name
    public void setfname(String f){
        this.f_name = f;
    }
    // getting phone number
    public String getlname(){
        return this.l_name;
    }
    // setting phone number
    public void setlname(String l){
        this.l_name = l;
    }

    public String getmobile(){
        return this.mobile;
    }
    // setting phone number
    public void setmobile(String m){
        this.mobile = m;
    }
    public String getdobirth(){
        return this.dobirth;
    }
    // setting phone number
    public void setdobirth(String d){
        this.dobirth = d;
    }
    public String getemail(){
        return this.E_mail;
    }
    // setting phone number
    public void setemail(String e){
        this.E_mail = e;
    }
    public String getinsti1(){
        return this.insti1;
    }
    // setting phone number
    public void setinsti1(String i){
        this.insti1 = i;
    }

    public String getinsti2(){
        return this.insti2;
    }
    // setting phone number
    public void setinsti2(String i){
        this.insti2 = i;
    }
    public String getinsti3(){
        return this.insti3;
    }
    // setting phone number
    public void setinsti3(String i){
        this.insti3 = i;
    }
    public String getmark1(){
        return this.mark1;
    }
    // setting phone number
    public void setmark1(String m){
        this.mark1 = m;
    }

    public String getmark2(){
        return this.mark2;
    }
    // setting phone number
    public void setmark2(String m){
        this.mark2 = m;
    }
    public String getmark3(){
        return this.mark3;
    }
    // setting phone number
    public void setmark3(String m){
        this.mark3 = m;
    }

    public String getdate1(){
        return this.date1;
    }
    // setting phone number
    public void setdate1(String d){
        this.date1 = d;
    }
    public String getdate2(){
        return this.date2;
    }
    // setting phone number
    public void setdate2(String d){
        this.date2 = d;
    }
    public String getadate1(){
        return this.adate1;
    }
    // setting phone number
    public void setadate1(String d){
        this.adate1 = d;
    }
    public String getadate2(){
        return this.adate2;
    }
    // setting phone number
    public void setadate2(String d){
        this.adate2 = d;
    }

    public String getexperience1(){
        return this.experience1;
    }
    // setting phone number
    public void setexperience1(String e){
        this.experience1 = e;
    }
    public String getexperience2(){
        return this.experience2;
    }
    // setting phone number
    public void setexperience2(String e){
        this.experience2 = e;
    }
    public String getaexperience1(){
        return this.aexperience1;
    }
    // setting phone number
    public void setaexperience1(String e){
        this.aexperience1 = e;
    }
    public String getaexperience2(){
        return this.aexperience2;
    }
    // setting phone number
    public void setaexperience2(String e){
        this.aexperience2 = e;
    }




}

