package com.example.shabaz.cvbuilderoffline;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class showall extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showall);



        database db = new database(this);
// Reading all contacts
        Log.d("Reading: ", "Reading all contacts..");
        List<builder> contacts = db.getAllContacts();
        String log=null;
        String [] contact_array = new String[contacts.size()];
        int i=0;
        for (builder cn : contacts) {
            contact_array[i] = cn.getfname() +"-"+ cn.getlname() ;
            //log = log + "Id: " + cn.getID() + " ,Name: " + cn.getfname() + ",Phone: " + cn.getlname();
// Writing Contacts to log
            // Log.d("Name: ", log);
            i++;
        }
        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1 , contact_array);
        ListView listView = (ListView) findViewById(R.id.listView1);
        listView.setAdapter(adapter);




        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String itemPosition = Integer.toString(position);
// When clicked, show a toast with the TextView text
                Toast.makeText(getApplicationContext(),
                        ((TextView) view).getText() + itemPosition,
                        Toast.LENGTH_SHORT).show();
                String product = ((TextView) view).getText().toString();
// Launching new Activity on selecting single List Item
                Intent i = new Intent(getApplicationContext(),
                        profile.class);
// sending data to new activity
                i.putExtra("product", product);
                startActivity(i);
            }
        });


    }

}
